import nltk
from nltk.chat.util import Chat, reflections
from nltk.classify import NaiveBayesClassifier
import random
from datetime import datetime

nltk.download('punkt')

intents = [
    {"intent": "greeting", "patterns": ["hi", "hello", "hey", "howdy"], "responses": ["Hello!", "Hi there!", "Hey! How can I assist you?"]},
    {"intent": "goodbye", "patterns": ["bye", "goodbye", "see you"], "responses": ["Goodbye!", "Take care!", "See you later!"]},
    {"intent": "name", "patterns": ["what is your name?", "who are you?", "tell me your name"], "responses": ["I am Mark11, your friendly chatbot.", "I am Mark11, an AI chatbot created by Salil."]},
    {"intent": "help", "patterns": ["help", "assist me", "I need help", "can you help"], "responses": ["Sure! What do you need help with?", "I'm here to help. What can I assist you with?"]},
    {"intent": "time", "patterns": ["what time is it?", "tell me the time", "what's the time"], "responses": ["The current time is: {time}"]},
    {"intent": "weather", "patterns": ["what's the weather?", "how's the weather?", "weather update"], "responses": ["I don't have live weather data, but you can check your local weather service."]},
    {"intent": "joke", "patterns": ["tell me a joke", "make me laugh", "tell a joke"], "responses": ["Why don't skeletons fight each other? They don't have the guts.", "Why did the computer go to the doctor? Because it had a virus!"]},
    {"intent": "location", "patterns": ["where are you from?", "where do you live?", "your location"], "responses": ["I live in the virtual world.", "I'm from the digital realm."]},
]

def prepare_data():
    training_data = []
    for intent in intents:
        for pattern in intent["patterns"]:
            training_data.append((pattern, intent["intent"]))
    return training_data

def extract_features(text):
    return {word: True for word in text.split()}

def train_classifier():
    training_data = prepare_data()
    featuresets = [(extract_features(text), intent) for (text, intent) in training_data]
    classifier = NaiveBayesClassifier.train(featuresets)
    return classifier

def chatbot_interface():
    classifier = train_classifier()
    print("Hello! I'm Mark11, your advanced chatbot. Type 'bye' to exit.")
    
    while True:
        user_input = input("You: ").lower()
        
        current_hour = datetime.now().hour
        if current_hour < 12:
            time_based_greeting = "Good morning!"
        elif 12 <= current_hour < 18:
            time_based_greeting = "Good afternoon!"
        else:
            time_based_greeting = "Good evening!"
        
        if user_input == 'bye':
            print("Mark11: Goodbye! Take care.")
            break
        
        if "name" in user_input:
            print(f"Mark11: {time_based_greeting} I am Mark11, your friendly chatbot.")
            continue
        
        features = extract_features(user_input)
        intent = classifier.classify(features)
        
        for intent_data in intents:
            if intent_data["intent"] == intent:
                response = random.choice(intent_data['responses'])
                
                if "{time}" in response:
                    response = response.format(time=datetime.now().strftime('%H:%M:%S'))
                
                print(f"Mark11: {response}")
                break

if __name__ == "__main__":
    chatbot_interface()
